# 픽 런처 (PickLauncher)

영웅 선택창 느낌의 레이아웃으로 만든 안드로이드 홈 런처입니다. (Kotlin + Jetpack Compose)
게임의 캐릭터·로고 이미지는 사용하지 않고, 육각 슬롯 / 하단 로스터 / 주황색 확인 버튼 구성만 참고했습니다.

## 사용법
- 하단 로스터에서 앱 아이콘을 탭하면 중앙에 크게 표시되고 우측 상단에 이름이 나옵니다.
- **확인** 버튼을 누르면 선택한 앱이 실행됩니다.
- 아이콘을 **길게 누르면** 위쪽 육각 슬롯(최대 5개)에 고정됩니다. 슬롯을 길게 누르면 해제됩니다.

## 빌드 방법
1. Android Studio (Koala 이상 권장)에서 이 폴더(`PickLauncher`)를 엽니다.
2. Gradle Sync가 끝나면 `Build > Build APK(s)` 를 실행합니다.
3. APK 위치: `app/build/outputs/apk/debug/app-debug.apk`
4. 폰에 설치 후 홈 버튼을 누르면 "항상 / 한 번만" 선택창에서 **픽 런처**를 고르면 됩니다.

## 구조
- `app/src/main/AndroidManifest.xml` : HOME 인텐트 필터, 앱 목록 조회용 `<queries>`
- `app/src/main/java/com/example/picklauncher/MainActivity.kt` : 전체 UI와 로직
- `app/src/main/res/` : 테마, 문자열, 런처 아이콘

## 설정 값
- minSdk 26 / targetSdk 34, AGP 8.5.2, Kotlin 1.9.24, Compose 컴파일러 1.5.14
