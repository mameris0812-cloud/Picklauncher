package com.example.picklauncher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ───────────── 색상 ─────────────
private val Orange = Color(0xFFF99E1A)
private val OrangeDark = Color(0xFFD97F00)
private val IceBlue = Color(0xFF9BE3FF)
private val PanelDark = Color(0xCC121A28)
private val SlotLine = Color(0xFFB9C6DA)
private val BgTop = Color(0xFF2B3A55)
private val BgBottom = Color(0xFF0E1522)

private const val SLOT_COUNT = 5

// ───────────── 데이터 ─────────────
data class AppEntry(val label: String, val pkg: String, val icon: ImageBitmap)

// 육각형 (OW 슬롯 모양, 꼭짓점이 위로)
private val HexShape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    moveTo(w / 2f, 0f)
    lineTo(w, h * 0.25f)
    lineTo(w, h * 0.75f)
    lineTo(w / 2f, h)
    lineTo(0f, h * 0.75f)
    lineTo(0f, h * 0.25f)
    close()
}

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                BackHandler { /* 홈 화면이므로 뒤로가기 무시 */ }
                LauncherScreen(resumeTick)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++ // 앱 설치/삭제 후 돌아오면 목록 갱신
    }
}

// ───────────── 앱 목록 / 저장 ─────────────
private fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            AppEntry(
                label = ri.loadLabel(pm).toString(),
                pkg = ri.activityInfo.packageName,
                icon = ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
            )
        }
        .sortedBy { it.label.lowercase() }
}

private fun loadSlots(prefs: SharedPreferences): List<String> {
    val raw = prefs.getString("slots", "") ?: ""
    val parts = raw.split("|")
    return List(SLOT_COUNT) { parts.getOrNull(it) ?: "" }
}

private fun saveSlots(prefs: SharedPreferences, slots: List<String>) {
    prefs.edit().putString("slots", slots.joinToString("|")).apply()
}

private fun launchApp(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(it)
    }
}

// ───────────── 화면 ─────────────
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherScreen(resumeTick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("pick_launcher", Context.MODE_PRIVATE) }

    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var slots by remember { mutableStateOf(loadSlots(prefs)) }
    var selectedPkg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(resumeTick) {
        apps = withContext(Dispatchers.Default) { loadApps(ctx) }
    }

    val selected = apps.firstOrNull { it.pkg == selectedPkg } ?: apps.firstOrNull()

    fun updateSlots(new: List<String>) {
        slots = new
        saveSlots(prefs, new)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
    ) {
        // 배경 장식: 은은한 대각선 빛 띠
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        0.0f to Color.Transparent,
                        0.45f to Color(0x14FFFFFF),
                        0.55f to Color.Transparent,
                        1.0f to Color.Transparent
                    )
                )
        )

        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // ── 헤더 ──
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "런처",
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black,
                        fontStyle = FontStyle.Italic
                    )
                    Text(
                        "앱을 선택하십시오",
                        color = IceBlue,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic
                    )
                }
                Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("+", color = Orange, fontSize = 26.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(4.dp))
                        Text(
                            selected?.label ?: "-",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            fontStyle = FontStyle.Italic,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.End
                        )
                    }
                    Text(
                        "설치된 앱 ${apps.size}개",
                        color = SlotLine,
                        fontSize = 12.sp
                    )
                }
            }

            // ── 중앙: 선택한 앱 크게 ──
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(240.dp)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0x66F99E1A), Color.Transparent)
                            )
                        )
                )
                Crossfade(targetState = selected, label = "hero") { app ->
                    if (app != null) {
                        Image(
                            bitmap = app.icon,
                            contentDescription = app.label,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(170.dp)
                        )
                    }
                }
            }

            // ── 육각 슬롯 (즐겨찾기) ──
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                slots.forEachIndexed { index, pkg ->
                    val app = apps.firstOrNull { it.pkg == pkg }
                    HexSlot(
                        app = app,
                        isSelected = app != null && app.pkg == selected?.pkg,
                        onClick = { if (app != null) selectedPkg = app.pkg },
                        onLongClick = {
                            if (app != null) {
                                updateSlots(slots.toMutableList().also { it[index] = "" })
                            }
                        }
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            // ── 하단 로스터 (2줄, 가로 스크롤) ──
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                    .background(PanelDark)
                    .padding(6.dp)
            ) {
                LazyHorizontalGrid(
                    rows = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2 * 56.dp + 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(apps, key = { it.pkg }) { app ->
                        val isSel = app.pkg == selected?.pkg
                        Box(
                            Modifier
                                .size(56.dp)
                                .background(Color(0xFF1E2A40))
                                .border(
                                    width = if (isSel) 3.dp else 1.dp,
                                    color = if (isSel) Orange else Color(0x44FFFFFF)
                                )
                                .combinedClickable(
                                    onClick = { selectedPkg = app.pkg },
                                    onLongClick = {
                                        selectedPkg = app.pkg
                                        // 이미 고정돼 있으면 무시, 아니면 첫 빈 슬롯(없으면 마지막 슬롯)에 고정
                                        if (app.pkg !in slots) {
                                            val empty = slots.indexOfFirst { it.isEmpty() }
                                            val target = if (empty >= 0) empty else SLOT_COUNT - 1
                                            updateSlots(slots.toMutableList().also { it[target] = app.pkg })
                                        }
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = app.icon,
                                contentDescription = app.label,
                                modifier = Modifier
                                    .size(44.dp)
                                    .alpha(if (isSel) 1f else 0.85f)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ── 확인 버튼 ──
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .width(200.dp)
                        .height(46.dp)
                        .background(Brush.verticalGradient(listOf(Orange, OrangeDark)))
                        .clickable(enabled = selected != null) {
                            selected?.let { launchApp(ctx, it.pkg) }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "확인",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.height(6.dp))

            // ── 조작 안내 ──
            Text(
                "탭: 앱 선택   ·   길게 누르기: 슬롯에 고정/해제   ·   확인: 실행",
                color = SlotLine,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HexSlot(
    app: AppEntry?,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Box(
        Modifier
            .size(width = 58.dp, height = 66.dp)
            .clip(HexShape)
            .background(if (app != null) Color(0xFF22304A) else Color(0x66101826))
            .border(
                width = if (isSelected) 3.dp else 2.dp,
                color = if (isSelected) Orange else SlotLine,
                shape = HexShape
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        contentAlignment = Alignment.Center
    ) {
        if (app != null) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier.size(34.dp)
            )
        } else {
            Text("•••", color = SlotLine, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}
